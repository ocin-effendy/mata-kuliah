package com.tutorial;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int panjang;
        int lebar;
        int tinggi;
        Balok b = new Balok();
        Scanner n = new Scanner(System.in);

        System.out.print("masukkan panjang : ");
        panjang = n.nextInt();
        System.out.print("masukkan panjang : ");
        lebar = n.nextInt();
        System.out.print("masukkan panjang : ");
        tinggi = n.nextInt();
        b.setPanjang(panjang);
        b.setLebar(lebar);
        b.setTinggi(tinggi);
        b.hasil();


    }
}
