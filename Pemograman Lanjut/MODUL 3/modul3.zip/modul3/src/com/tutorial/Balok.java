package com.tutorial;

public class Balok {


    private int panjang;
    private int lebar;
    private int tinggi;


    public void setPanjang(int panjang){
        this.panjang = panjang;
    }

    public int getPanjang(){
        return this.panjang;
    }

    public void setLebar(int lebar){
        this.lebar = lebar;
    }

    public int getLebar(){
        return this.lebar;
    }

    public void setTinggi(int tinggi){
        this.tinggi = tinggi;
    }

    public int getTinggi(){
        return this.tinggi;
    }

    public void hasil(){
        Perhitungan ph = new Perhitungan();
        System.out.println("Hasil Luas Balok : " + ph.luas(this));
        System.out.println("Hasil Volume Balok : " + ph.volume(this));
    }

    static boolean isCube(long input){
        boolean result = Math.round(Math.cbrt(input)) * Math.round(Math.cbrt(input)) * Math.round(Math.cbrt(input)) == input;
        return result;

    }


}
