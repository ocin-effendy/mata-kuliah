package com.tutorial;

public class Perhitungan {


    public int luas(Balok sisi){
        return sisi.getPanjang() * sisi.getLebar() * sisi.getTinggi();
    }

    public int volume(Balok sisi){
        return sisi.getPanjang() * sisi.getLebar() * sisi.getTinggi() * 4;
    }

}
