package com.code;

public interface CriticalDamage {

    double doubleDamage(double attackDamage);

}
